from django.apps import AppConfig


class GetlinksappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'getlinksapp'
    verbose_name = "暗链扫描平台"